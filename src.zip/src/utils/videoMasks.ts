import type { CSSProperties } from "react";
import type { VideoMask, VideoMaskShape } from "../types/timelineModel";

export const DEFAULT_VIDEO_MASK: Omit<VideoMask, "id"> = {
  enabled: true,
  shape: "rectangle",
  invert: false,
  positionX: 50,
  positionY: 50,
  width: 50,
  height: 50,
  feather: 0,
};

function finite(value: number, fallback: number) {
  return Number.isFinite(value) ? value : fallback;
}

function clamp(value: number, min: number, max: number, fallback: number) {
  return Math.max(min, Math.min(max, finite(value, fallback)));
}

export function createVideoMask(shape: VideoMaskShape): VideoMask {
  return {
    id: `mask-${crypto.randomUUID()}`,
    ...DEFAULT_VIDEO_MASK,
    shape,
  };
}

export function normalizeVideoMask(mask: VideoMask | undefined): VideoMask | undefined {
  if (!mask) return undefined;
  return {
    id: mask.id || `mask-${crypto.randomUUID()}`,
    enabled: mask.enabled !== false,
    shape: mask.shape === "ellipse" ? "ellipse" : "rectangle",
    invert: mask.invert === true,
    positionX: clamp(mask.positionX, -100, 200, 50),
    positionY: clamp(mask.positionY, -100, 200, 50),
    width: clamp(mask.width, 1, 300, 50),
    height: clamp(mask.height, 1, 300, 50),
    feather: clamp(mask.feather, 0, 300, 0),
  };
}

export function cloneVideoMask(mask: VideoMask | undefined): VideoMask | undefined {
  return mask ? { ...mask } : undefined;
}

export function videoMasksEqual(left: VideoMask | undefined, right: VideoMask | undefined) {
  return JSON.stringify(normalizeVideoMask(left) ?? null) ===
    JSON.stringify(normalizeVideoMask(right) ?? null);
}

export function activeVideoMask(mask: VideoMask | undefined) {
  return mask?.enabled !== false ? normalizeVideoMask(mask) : undefined;
}

export function resetVideoMask(mask: VideoMask): VideoMask {
  return {
    id: mask.id,
    ...DEFAULT_VIDEO_MASK,
    shape: mask.shape,
  };
}

export function videoMaskSummary(mask: VideoMask | undefined) {
  if (!mask) return "No mask";
  return `${mask.shape === "ellipse" ? "Ellipse" : "Rectangle"}${mask.invert ? " · inverted" : ""}`;
}

function escapeSvg(svg: string) {
  return `data:image/svg+xml,${encodeURIComponent(svg)}`;
}

/**
 * Program-space preview mask. The mask is intentionally authored against the
 * full Program canvas rather than source pixels, so video clips and Adjustment
 * Layers use the same onscreen geometry and export mapping.
 */
export function videoMaskCssStyle(
  mask: VideoMask | undefined,
  canvasAspect = 16 / 9,
): CSSProperties {
  const active = activeVideoMask(mask);
  if (!active) return {};

  const left = active.positionX - active.width / 2;
  const top = active.positionY - active.height / 2;
  const blurY = Math.max(0, active.feather) / 1080 * 100;
  const blurX = blurY / Math.max(0.01, canvasAspect);
  const background = active.invert ? "white" : "black";
  const foreground = active.invert ? "black" : "white";
  const filter = blurY > 0.0001 ? ` filter="url(#b)"` : "";
  const shape = active.shape === "ellipse"
    ? `<ellipse cx="${active.positionX}" cy="${active.positionY}" rx="${active.width / 2}" ry="${active.height / 2}" fill="${foreground}"${filter}/>`
    : `<rect x="${left}" y="${top}" width="${active.width}" height="${active.height}" fill="${foreground}"${filter}/>`;

  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" preserveAspectRatio="none"><defs><filter id="b" x="-60%" y="-60%" width="220%" height="220%"><feGaussianBlur stdDeviation="${blurX} ${blurY}"/></filter><mask id="m" maskUnits="userSpaceOnUse" x="0" y="0" width="100" height="100"><rect x="0" y="0" width="100" height="100" fill="${background}"/>${shape}</mask></defs><rect x="0" y="0" width="100" height="100" fill="white" mask="url(#m)"/></svg>`;
  const url = `url("${escapeSvg(svg)}")`;

  return {
    WebkitMaskImage: url,
    maskImage: url,
    WebkitMaskSize: "100% 100%",
    maskSize: "100% 100%",
    WebkitMaskRepeat: "no-repeat",
    maskRepeat: "no-repeat",
  } as CSSProperties;
}

export function videoMaskBounds(mask: VideoMask) {
  return {
    left: mask.positionX - mask.width / 2,
    right: mask.positionX + mask.width / 2,
    top: mask.positionY - mask.height / 2,
    bottom: mask.positionY + mask.height / 2,
  };
}
