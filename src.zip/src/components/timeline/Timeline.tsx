import {
  useEffect,
  useMemo,
  useRef,
  useState,
  type MouseEvent as ReactMouseEvent,
} from "react";

import type { Subtitle } from "../../types/subtitle";
import type { TimelineMarker } from "../../types/timeline";
import type {
  TimelineTrack as TimelineTrackModel,
  TimelineTrackId,
  TimelineTrackSettings,
  VideoTimelineClip,
  VideoTransitionType,
} from "../../types/timelineModel";

import { useVideoClipFrames } from "../../hooks/useVideoClipFrames";
import { buildTimelineModel } from "../../utils/timelineModel";

import SubtitleTrack from "./SubtitleTrack";
import TimelineRuler from "./TimelineRuler";
import VideoTrack from "./VideoTrack";
import WaveformTrack from "./WaveformTrack";

import "./Timeline.css";

type TimelineProps = {
  duration: number;
  currentTime: number;
  waveformsBySource: Record<string, number[]>;
  videoClips: VideoTimelineClip[];
  subtitles: Subtitle[];
  markers: TimelineMarker[];
  zoom: number;
  trackSettings: TimelineTrackSettings;

  selectedSubtitleId: string | null;
  selectedSubtitleIds: string[];
  selectedVideoClipId: string | null;

  onSeek?: (time: number) => void;
  onClearSubtitleSelection?: () => void;

  onVideoClipSelect?: (id: string) => void;
  onVideoClipMove?: (
    id: string,
    newTimelineStart: number,
  ) => void;
  onVideoClipResize?: (
    id: string,
    newTimelineStart: number,
    newTimelineEnd: number,
  ) => void;
  onVideoClipMoveToTrack?: (
    id: string,
    targetTrackId: TimelineTrackId,
    newTimelineStart: number,
  ) => void;
  onMediaDrop?: (
    assetId: string,
    targetTrackId: TimelineTrackId,
    timelineTime: number,
  ) => void;
  onCopyVideoClip?: () => void;
  onPasteVideoClip?: () => void;
  onDuplicateVideoClip?: () => void;
  canPasteVideoClip?: boolean;

  onSubtitleSelect?: (
    id: string,
    mode?: "single" | "toggle" | "range",
  ) => void;
  onSubtitleMove?: (id: string, newStartTime: number) => void;
  onSubtitleGroupMove?: (
    ids: string[],
    anchorId: string,
    newAnchorStartTime: number,
  ) => void;
  onSubtitleResize?: (
    id: string,
    newStartTime: number,
    newEndTime: number,
  ) => void;
  onMarkersChange?: (markers: TimelineMarker[]) => void;
  onZoomChange?: (zoom: number) => void;
  onToggleTrackLock?: (trackId: TimelineTrackId) => void;
  onToggleTrackMute?: (trackId: TimelineTrackId) => void;
  onToggleTrackHidden?: (trackId: TimelineTrackId) => void;
  onVideoTransitionChange?: (
    id: string,
    edge: "in" | "out",
    transition: { type?: VideoTransitionType; duration?: number },
  ) => void;
};

export const MIN_TIMELINE_ZOOM = 1;
export const MAX_TIMELINE_ZOOM = 12;
export const TIMELINE_ZOOM_STEP = 0.25;

const MIN_TRAILING_WORKSPACE_SECONDS = 10;
const MAX_TRAILING_WORKSPACE_SECONDS = 120;
const TRAILING_WORKSPACE_RATIO = 0.25;

function trailingWorkspaceDuration(contentDuration: number) {
  if (!Number.isFinite(contentDuration) || contentDuration <= 0) {
    return 30;
  }

  return Math.max(
    MIN_TRAILING_WORKSPACE_SECONDS,
    Math.min(
      MAX_TRAILING_WORKSPACE_SECONDS,
      contentDuration * TRAILING_WORKSPACE_RATIO,
    ),
  );
}

export function clampTimelineZoom(value: number) {
  return Math.max(MIN_TIMELINE_ZOOM, Math.min(MAX_TIMELINE_ZOOM, value));
}

function Timeline({
  duration,
  currentTime,
  waveformsBySource,
  videoClips,
  subtitles,
  markers,
  zoom,
  trackSettings,
  selectedSubtitleId,
  selectedSubtitleIds,
  selectedVideoClipId,
  onSeek,
  onClearSubtitleSelection,
  onVideoClipSelect,
  onVideoClipMove,
  onVideoClipResize,
  onVideoClipMoveToTrack,
  onMediaDrop,
  onCopyVideoClip,
  onPasteVideoClip,
  onDuplicateVideoClip,
  canPasteVideoClip = false,
  onSubtitleSelect,
  onSubtitleMove,
  onSubtitleGroupMove,
  onSubtitleResize,
  onMarkersChange,
  onZoomChange,
  onToggleTrackLock,
  onToggleTrackMute,
  onToggleTrackHidden,
  onVideoTransitionChange,
}: TimelineProps) {
  const scrollRef = useRef<HTMLDivElement | null>(null);
  const previousZoomRef = useRef(zoom);
  const timelineScaleInitializedRef = useRef(false);
  const [timelineViewportWidth, setTimelineViewportWidth] = useState(0);
  const [scaleReferenceDuration, setScaleReferenceDuration] = useState(1);
  const [workspaceDuration, setWorkspaceDuration] = useState(30);

  /*
   * Timeline scale and timeline extent are deliberately separate.
   *
   * `scaleReferenceDuration` is the time span that defines pixels-per-second at
   * 100% zoom. Once a project is initialized, ordinary clip move/trim edits do
   * NOT change it. Only the user's zoom control changes visual scale.
   *
   * `workspaceDuration` is just the scrollable canvas extent. It can grow when
   * content approaches/passes the right edge, without changing pixels-per-second.
   */
  const workspaceWidthRatio =
    scaleReferenceDuration > 0
      ? workspaceDuration / scaleReferenceDuration
      : 1;
  const workspaceContentWidthPercent = zoom * workspaceWidthRatio * 100;

  const playheadPosition =
    workspaceDuration > 0 ? (currentTime / workspaceDuration) * 100 : 0;
  const timelineTrackWidthPx =
    Math.max(1, timelineViewportWidth - 118) * zoom * workspaceWidthRatio;
  const framesByClipId = useVideoClipFrames(
    videoClips,
    workspaceDuration,
    timelineTrackWidthPx,
  );

  const markerTimes = useMemo(
    () => markers.map((marker) => marker.time).sort((a, b) => a - b),
    [markers],
  );

  const timelineTracks = useMemo(
    () =>
      buildTimelineModel({
        duration: workspaceDuration,
        videoClips,
        subtitles,
        trackSettings,
      }),
    [
      workspaceDuration,
      videoClips,
      subtitles,
      trackSettings,
    ],
  );

  const setTimelineZoom = (nextZoom: number) => {
    onZoomChange?.(clampTimelineZoom(nextZoom));
  };

  useEffect(() => {
    if (!Number.isFinite(duration) || duration <= 0) {
      timelineScaleInitializedRef.current = false;
      setScaleReferenceDuration(1);
      setWorkspaceDuration(30);
      return;
    }

    if (!timelineScaleInitializedRef.current) {
      timelineScaleInitializedRef.current = true;
      setScaleReferenceDuration(duration);
      setWorkspaceDuration(duration + trailingWorkspaceDuration(duration));
      return;
    }

    /*
     * Grow only when content gets close to the current right edge. Keeping a
     * reserve prevents the scrollbar width from changing for every tiny trim.
     * Crucially, growing this canvas never changes scaleReferenceDuration.
     */
    const reserve = trailingWorkspaceDuration(scaleReferenceDuration);
    const growThreshold = workspaceDuration - Math.max(4, reserve * 0.25);

    if (duration >= growThreshold) {
      const nextWorkspaceDuration = duration + reserve;

      if (nextWorkspaceDuration > workspaceDuration + 0.01) {
        setWorkspaceDuration(nextWorkspaceDuration);
      }
    }
  }, [duration, scaleReferenceDuration, workspaceDuration]);

  useEffect(() => {
    const scroll = scrollRef.current;

    if (!scroll) {
      return;
    }

    const updateViewportWidth = () => {
      setTimelineViewportWidth(scroll.clientWidth);
    };

    updateViewportWidth();

    const observer = new ResizeObserver(updateViewportWidth);
    observer.observe(scroll);

    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    const scroll = scrollRef.current;
    const previousZoom = previousZoomRef.current;

    previousZoomRef.current = zoom;

    if (!scroll || previousZoom === zoom) {
      return;
    }

    const previousContentWidth =
      zoom > 0 ? (scroll.scrollWidth * previousZoom) / zoom : scroll.scrollWidth;
    const viewportCenter = scroll.scrollLeft + scroll.clientWidth / 2;
    const centerRatio = previousContentWidth > 0 ? viewportCenter / previousContentWidth : 0;

    window.requestAnimationFrame(() => {
      const nextContentWidth = scroll.scrollWidth;
      scroll.scrollLeft = Math.max(
        0,
        centerRatio * nextContentWidth - scroll.clientWidth / 2,
      );
    });
  }, [zoom]);

  const zoomOut = () => setTimelineZoom(zoom - TIMELINE_ZOOM_STEP);
  const zoomIn = () => setTimelineZoom(zoom + TIMELINE_ZOOM_STEP);

  const addMarker = (time: number) => {
    if (workspaceDuration <= 0) {
      return;
    }

    const safeTime = Math.max(0, Math.min(workspaceDuration, time));
    const existing = markers.find((marker) => Math.abs(marker.time - safeTime) < 0.05);

    if (existing) {
      return;
    }

    onMarkersChange?.(
      [...markers, { id: crypto.randomUUID(), time: safeTime }].sort(
        (a, b) => a.time - b.time,
      ),
    );
  };

  const addMarkerAtEvent = (event: ReactMouseEvent<HTMLElement>) => {
    if (workspaceDuration <= 0) {
      return;
    }

    const rect = event.currentTarget.getBoundingClientRect();
    const labelWidth = 118;
    const trackWidth = Math.max(1, rect.width - labelWidth);
    const ratio = (event.clientX - rect.left - labelWidth) / trackWidth;

    addMarker(ratio * workspaceDuration);
  };

  const removeMarker = (id: string) => {
    onMarkersChange?.(markers.filter((marker) => marker.id !== id));
  };

  const removeNearestMarkerAtPlayhead = () => {
    if (markers.length === 0) {
      return;
    }

    const nearest = markers.reduce((best, marker) =>
      Math.abs(marker.time - currentTime) < Math.abs(best.time - currentTime)
        ? marker
        : best,
    );

    // Only remove a marker that is reasonably close to the playhead.
    // 0.5 seconds keeps Shift+M predictable rather than deleting a distant marker.
    if (Math.abs(nearest.time - currentTime) <= 0.5) {
      removeMarker(nearest.id);
    }
  };

  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      const target = event.target as HTMLElement;

      if (
        target.tagName === "INPUT" ||
        target.tagName === "TEXTAREA" ||
        target.isContentEditable ||
        event.metaKey ||
        event.ctrlKey ||
        event.altKey
      ) {
        return;
      }

      if (event.key.toLowerCase() === "m") {
        event.preventDefault();

        if (event.shiftKey) {
          removeNearestMarkerAtPlayhead();
        } else {
          addMarker(currentTime);
        }
      }
    };

    window.addEventListener("keydown", handleKeyDown);

    return () => {
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, [currentTime, workspaceDuration, markers]);

  const handleWheel = (event: React.WheelEvent<HTMLDivElement>) => {
    if (!event.metaKey && !event.ctrlKey) {
      return;
    }

    event.preventDefault();
    setTimelineZoom(zoom + (event.deltaY < 0 ? TIMELINE_ZOOM_STEP : -TIMELINE_ZOOM_STEP));
  };

  const renderTimelineTrack = (
    track: TimelineTrackModel,
  ) => {
    switch (track.kind) {
      case "video":
        return (
          <VideoTrack
            key={track.id}
            duration={workspaceDuration}
            currentTime={currentTime}
            track={track}
            selectedVideoClipId={selectedVideoClipId}
            framesByClipId={framesByClipId}
            onSeek={onSeek}
            onSelect={onVideoClipSelect}
            onMove={onVideoClipMove}
            onMoveToTrack={onVideoClipMoveToTrack}
            onMediaDrop={onMediaDrop}
            onResize={onVideoClipResize}
            onToggleLock={onToggleTrackLock}
            onToggleHidden={onToggleTrackHidden}
            onTransitionChange={onVideoTransitionChange}
          />
        );

      case "subtitle":
        return (
          <SubtitleTrack
            key={track.id}
            duration={workspaceDuration}
            track={track}
            subtitles={subtitles}
            selectedSubtitleId={selectedSubtitleId}
            selectedSubtitleIds={selectedSubtitleIds}
            markerTimes={markerTimes}
            playheadTime={currentTime}
            onSubtitleSelect={onSubtitleSelect}
            onSubtitleMove={onSubtitleMove}
            onSubtitleGroupMove={onSubtitleGroupMove}
            onSubtitleResize={onSubtitleResize}
            onSeek={onSeek}
            onToggleLock={onToggleTrackLock}
            onToggleHidden={onToggleTrackHidden}
          />
        );

      case "audio":
        return (
          <WaveformTrack
            key={track.id}
            duration={workspaceDuration}
            track={track}
            waveformsBySource={waveformsBySource}
            onSeek={onSeek}
            onToggleMute={onToggleTrackMute}
          />
        );

      default:
        return null;
    }
  };


  return (
    <section className="timeline-panel">
      <div className="timeline-header">
        <div className="timeline-title-group">
          <h2>Timeline</h2>
          <span className="timeline-help">
            V1/V2 compositing · linked A1/A2 · drag media or clips between video tracks
          </span>
        </div>

        <div className="timeline-controls">
          <div className="timeline-edit-actions" aria-label="Video clip actions">
            <button
              type="button"
              className="timeline-action-button"
              onClick={onCopyVideoClip}
              disabled={!selectedVideoClipId}
              title="Copy selected video clip (⌘C / Ctrl+C)"
            >
              Copy
            </button>

            <button
              type="button"
              className="timeline-action-button"
              onClick={onPasteVideoClip}
              disabled={!canPasteVideoClip}
              title="Paste video clip at playhead (⌘V / Ctrl+V)"
            >
              Paste
            </button>

            <button
              type="button"
              className="timeline-action-button"
              onClick={onDuplicateVideoClip}
              disabled={!selectedVideoClipId}
              title="Duplicate selected video clip (⌘D / Ctrl+D)"
            >
              Duplicate
            </button>
          </div>

          <button
            type="button"
            className="timeline-zoom-button"
            onClick={zoomOut}
            disabled={zoom <= MIN_TIMELINE_ZOOM}
            aria-label="Zoom timeline out"
          >
            −
          </button>

          <input
            className="timeline-zoom-slider"
            type="range"
            min={MIN_TIMELINE_ZOOM}
            max={MAX_TIMELINE_ZOOM}
            step={TIMELINE_ZOOM_STEP}
            value={zoom}
            onChange={(event) => setTimelineZoom(Number(event.target.value))}
            aria-label="Timeline zoom"
          />

          <button
            type="button"
            className="timeline-zoom-button"
            onClick={zoomIn}
            disabled={zoom >= MAX_TIMELINE_ZOOM}
            aria-label="Zoom timeline in"
          >
            +
          </button>

          <span className="timeline-zoom-label">{Math.round(zoom * 100)}%</span>
        </div>
      </div>

      <div ref={scrollRef} className="timeline-scroll" onWheel={handleWheel}>
        <div
          className="timeline-content"
          style={{
            width: `${workspaceContentWidthPercent}%`,
          }}
        >
          <TimelineRuler
            duration={workspaceDuration}
            zoom={zoom * workspaceWidthRatio}
            currentTime={currentTime}
            onSeek={onSeek}
          />

          <div
            className="timeline-track-stack"
            onDoubleClick={addMarkerAtEvent}
            onMouseDown={(event) => {
              const target = event.target as HTMLElement;

              if (
                target.closest(".subtitle-clip") ||
                target.closest(".timeline-user-marker") ||
                target.closest("button") ||
                target.closest("input")
              ) {
                return;
              }

              onClearSubtitleSelection?.();
            }}
          >
            {timelineTracks.map(renderTimelineTrack)}

            <div className="timeline-marker-layer" aria-hidden="true">
              {markers.map((marker) => (
                <button
                  key={marker.id}
                  type="button"
                  className="timeline-user-marker"
                  style={{
                    left: `${
                      workspaceDuration > 0
                        ? (marker.time / workspaceDuration) * 100
                        : 0
                    }%`,
                  }}
                  title={`Marker ${marker.time.toFixed(2)}s — click to remove`}
                  onClick={(event) => {
                    event.stopPropagation();
                    removeMarker(marker.id);
                  }}
                >
                  <span className="timeline-user-marker-cap" />
                </button>
              ))}
            </div>

            <div
              className="timeline-playhead"
              style={{
                left: `calc(118px + (100% - 118px) * ${playheadPosition / 100})`,
              }}
              aria-hidden="true"
            >
              <span className="timeline-playhead-cap" />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export default Timeline;
