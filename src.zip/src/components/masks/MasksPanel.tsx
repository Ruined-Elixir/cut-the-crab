import { useEffect, useRef, useState, type MouseEvent as ReactMouseEvent } from "react";
import type { VideoMask, VideoMaskShape } from "../../types/timelineModel";
import { createVideoMask, resetVideoMask, videoMaskSummary } from "../../utils/videoMasks";
import "./MasksPanel.css";

type Props = {
  open: boolean;
  targetName: string;
  targetDetail?: string;
  mask?: VideoMask;
  disabled?: boolean;
  onChange: (mask: VideoMask | undefined) => void;
  onClose: () => void;
  onBeginContinuousChange?: () => void;
  onEndContinuousChange?: () => void;
  onDiscreteChange?: () => void;
};

type Position = { x: number; y: number };
const PANEL_WIDTH = 360;
const PANEL_HEIGHT = 560;

function clampPanelPosition(position: Position): Position {
  return {
    x: Math.max(8, Math.min(window.innerWidth - PANEL_WIDTH - 8, position.x)),
    y: Math.max(8, Math.min(window.innerHeight - Math.min(PANEL_HEIGHT, window.innerHeight - 16) - 8, position.y)),
  };
}

function MaskSlider({ label, value, min, max, step, suffix = "", disabled, onChange, onBegin, onEnd }: {
  label: string; value: number; min: number; max: number; step: number; suffix?: string; disabled?: boolean;
  onChange: (value: number) => void; onBegin?: () => void; onEnd?: () => void;
}) {
  const activeRef = useRef(false);
  useEffect(() => {
    const end = () => {
      if (!activeRef.current) return;
      activeRef.current = false;
      onEnd?.();
    };
    window.addEventListener("pointerup", end, true);
    window.addEventListener("pointercancel", end, true);
    window.addEventListener("blur", end);
    return () => {
      window.removeEventListener("pointerup", end, true);
      window.removeEventListener("pointercancel", end, true);
      window.removeEventListener("blur", end);
    };
  }, [onEnd]);

  return (
    <label className="mask-panel-slider">
      <span>{label}</span>
      <input
        type="range" min={min} max={max} step={step} value={value} disabled={disabled}
        onPointerDown={(event) => {
          if (disabled || event.button !== 0 || activeRef.current) return;
          activeRef.current = true;
          onBegin?.();
        }}
        onChange={(event) => onChange(Number(event.target.value))}
      />
      <output>{Number.isInteger(value) ? value : value.toFixed(1)}{suffix}</output>
    </label>
  );
}

export default function MasksPanel({ open, targetName, targetDetail, mask, disabled = false, onChange, onClose, onBeginContinuousChange, onEndContinuousChange, onDiscreteChange }: Props) {
  const [position, setPosition] = useState<Position>(() => ({ x: Math.max(12, window.innerWidth - PANEL_WIDTH - 24), y: 90 }));
  const dragOriginRef = useRef<{ x: number; y: number; px: number; py: number } | null>(null);

  useEffect(() => {
    const resize = () => setPosition((current) => clampPanelPosition(current));
    window.addEventListener("resize", resize);
    return () => window.removeEventListener("resize", resize);
  }, []);

  useEffect(() => {
    if (!open) return;
    const key = (event: KeyboardEvent) => { if (event.key === "Escape") onClose(); };
    window.addEventListener("keydown", key);
    return () => window.removeEventListener("keydown", key);
  }, [onClose, open]);

  if (!open) return null;

  const beginDrag = (event: ReactMouseEvent<HTMLDivElement>) => {
    if (event.button !== 0 || (event.target as HTMLElement).closest("button,input")) return;
    event.preventDefault();
    dragOriginRef.current = { x: event.clientX, y: event.clientY, px: position.x, py: position.y };
    const move = (e: MouseEvent) => {
      const o = dragOriginRef.current; if (!o) return;
      setPosition(clampPanelPosition({ x: o.px + e.clientX - o.x, y: o.py + e.clientY - o.y }));
    };
    const up = () => {
      dragOriginRef.current = null;
      window.removeEventListener("mousemove", move);
      window.removeEventListener("mouseup", up);
    };
    window.addEventListener("mousemove", move);
    window.addEventListener("mouseup", up);
  };

  const discrete = (next: VideoMask | undefined) => {
    if (disabled) return;
    onDiscreteChange?.();
    onChange(next);
  };
  const patch = (next: Partial<VideoMask>) => {
    if (!mask || disabled) return;
    onChange({ ...mask, ...next });
  };
  const add = (shape: VideoMaskShape) => discrete(createVideoMask(shape));

  return (
    <aside className={`masks-panel ${disabled ? "disabled" : ""}`} style={{ left: position.x, top: position.y }}>
      <div className="masks-panel-header" onMouseDown={beginDrag}>
        <div><strong>Masks</strong><small>{targetName}{targetDetail ? ` · ${targetDetail}` : ""}</small></div>
        <button type="button" onClick={onClose} aria-label="Close Masks">×</button>
      </div>

      {!mask ? (
        <div className="masks-panel-empty">
          <strong>No mask</strong>
          <span>Add a Program-space mask. You can then move and resize it directly in the Program Monitor.</span>
          <div>
            <button disabled={disabled} onClick={() => add("rectangle")}>+ Rectangle</button>
            <button disabled={disabled} onClick={() => add("ellipse")}>+ Ellipse</button>
          </div>
        </div>
      ) : (
        <>
          <div className="masks-panel-toolbar">
            <label><input type="checkbox" checked={mask.enabled !== false} disabled={disabled} onChange={(e) => discrete({ ...mask, enabled: e.target.checked })}/> Enable</label>
            <span>{videoMaskSummary(mask)}</span>
          </div>
          <div className="masks-panel-body">
            <section>
              <div className="mask-shape-switch">
                <button className={mask.shape === "rectangle" ? "active" : ""} disabled={disabled} onClick={() => discrete({ ...mask, shape: "rectangle" })}>Rectangle</button>
                <button className={mask.shape === "ellipse" ? "active" : ""} disabled={disabled} onClick={() => discrete({ ...mask, shape: "ellipse" })}>Ellipse</button>
              </div>
              <label className="mask-invert-toggle"><input type="checkbox" checked={mask.invert} disabled={disabled} onChange={(e) => discrete({ ...mask, invert: e.target.checked })}/> Invert mask</label>
            </section>
            <section>
              <h4>Position</h4>
              <MaskSlider label="X" value={mask.positionX} min={-100} max={200} step={0.5} suffix="%" disabled={disabled} onBegin={onBeginContinuousChange} onEnd={onEndContinuousChange} onChange={(positionX) => patch({ positionX })}/>
              <MaskSlider label="Y" value={mask.positionY} min={-100} max={200} step={0.5} suffix="%" disabled={disabled} onBegin={onBeginContinuousChange} onEnd={onEndContinuousChange} onChange={(positionY) => patch({ positionY })}/>
            </section>
            <section>
              <h4>Size</h4>
              <MaskSlider label="Width" value={mask.width} min={1} max={300} step={0.5} suffix="%" disabled={disabled} onBegin={onBeginContinuousChange} onEnd={onEndContinuousChange} onChange={(width) => patch({ width })}/>
              <MaskSlider label="Height" value={mask.height} min={1} max={300} step={0.5} suffix="%" disabled={disabled} onBegin={onBeginContinuousChange} onEnd={onEndContinuousChange} onChange={(height) => patch({ height })}/>
            </section>
            <section>
              <h4>Edge</h4>
              <MaskSlider label="Feather" value={mask.feather} min={0} max={300} step={1} suffix=" px" disabled={disabled} onBegin={onBeginContinuousChange} onEnd={onEndContinuousChange} onChange={(feather) => patch({ feather })}/>
            </section>
          </div>
          <div className="masks-panel-footer">
            <span>Drag the shape in Program to reposition · drag corner handles to resize.</span>
            <div><button disabled={disabled} onClick={() => discrete(resetVideoMask(mask))}>Reset</button><button className="danger" disabled={disabled} onClick={() => discrete(undefined)}>Remove</button></div>
          </div>
        </>
      )}
    </aside>
  );
}
